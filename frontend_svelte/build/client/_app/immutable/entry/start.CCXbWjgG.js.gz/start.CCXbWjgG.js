import{a as t}from"../chunks/entry.BAu7sNJh.js";export{t as start};
